import numpy as np
from skopt import gp_minimize
from skopt.space import Real
import pickle
import pandas as pd
import ssm


class GLMHMMOptimizer:
    def __init__(self, num_states=2, obs_dim=1, input_dim=8, num_categories=2, max_iters=200, tol=1e-3):
        """
        Initializes the GLM-HMM optimizer with default parameters.
        
        Args:
            num_states (int): Number of discrete latent states (default=2).
            obs_dim (int): Dimensionality of the observed data (default=1).
            input_dim (int): Number of covariates or input dimensions (default=8).
            num_categories (int): Number of output categories (default=2).
            max_iters (int): Maximum number of EM iterations (default=200).
            tol (float): Tolerance for convergence (default=1e-3).
        """
        self.num_states = num_states
        self.obs_dim = obs_dim
        self.input_dim = input_dim
        self.num_categories = num_categories
        self.max_iters = max_iters
        self.tol = tol
        self.results = []
        self.posterior_probabilities_list = []
        self.observed_states_list = []
        self.glm_weights_list = []

    def fit_glmhmm(self, params, responses, inputs, saved_states):
        """
        Fits the GLM-HMM and evaluates RMSE and other metrics.

        Args:
            params (list): List of prior parameters [mean_value_1, mean_value_2, sigma_value_1, sigma_value_2, alpha_value].
            responses (np.ndarray): Binary responses (shape: [num_trials, 1]).
            inputs (np.ndarray): Covariates or input data (shape: [num_trials, input_dim]).
            saved_states (list): Ground truth states ("ENG" or "PER").
        
        Returns:
            dict: Metrics including RMSE, log-likelihood, and optimized weights.
        """
        mean_value_1, mean_value_2, sigma_value_1, sigma_value_2, alpha_value = params

        prior_means = [(0, mean_value_1), (mean_value_2, 0)]
        prior_sigmas = [(0.01, sigma_value_1), (sigma_value_2, 0.01)]
        prior_alpha = alpha_value

        # Instantiate the GLM-HMM
        model = ssm.HMM(
            self.num_states,
            self.obs_dim,
            self.input_dim,
            observations="ind_input_driven_obs",
            observation_kwargs=dict(C=self.num_categories, prior_means=prior_means, prior_sigmas=prior_sigmas),
            transitions="sticky",
            transition_kwargs=dict(alpha=prior_alpha, kappa=0)
        )

        # Fit the model using EM
        model.fit(responses, inputs=inputs, method="em", num_iters=self.max_iters, tolerance=self.tol)

        # Extract posterior probabilities
        posterior_probs = model.expected_states(data=responses, input=inputs)[0]
        predicted_states = np.argmax(posterior_probs, axis=1)

        # Convert saved_states to numeric format
        state_numeric = [1 if state == "ENG" else 0 for state in saved_states]

        # RMSE calculations
        rmse_total = np.mean(predicted_states != state_numeric)

        per_indices = [i for i, state in enumerate(state_numeric) if state == 0]
        rmse_per = np.mean(predicted_states[per_indices] != np.array(state_numeric)[per_indices]) if per_indices else np.nan

        eng_indices = [i for i, state in enumerate(state_numeric) if state == 1]
        rmse_eng = np.mean(predicted_states[eng_indices] != np.array(state_numeric)[eng_indices]) if eng_indices else np.nan

        # Log likelihood
        log_likelihood = model.log_likelihood(responses, inputs=inputs)

        return {
            "rmse_total": rmse_total,
            "rmse_per": rmse_per,
            "rmse_eng": rmse_eng,
            "log_likelihood": log_likelihood,
            "prior_means": prior_means,
            "prior_sigmas": prior_sigmas,
            "predicted_states": predicted_states,
            "posterior_probs": posterior_probs,
            "weights_state_1": model.observations.params[0],
            "weights_state_2": model.observations.params[1],
            "transitions_log_ps": np.exp(model.transitions.log_Ps)
        }

    def bayesian_optimization(self, responses, inputs, saved_states, n_calls=30, random_state=42):
        """
        Runs Bayesian Optimization to find the best priors.
        """
        space = [
            Real(0.0, 2.0, name='mean_value_1'),
            Real(0.0, 2.0, name='mean_value_2'),
            Real(1.0, 5.0, name='sigma_value_1'),
            Real(1.0, 5.0, name='sigma_value_2'),
            Real(1.0, 3.0, name='alpha_value')
        ]

        def objective(params):
            result = self.fit_glmhmm(params, responses, inputs, saved_states)
            return result["rmse_total"]

        return gp_minimize(objective, space, n_calls=n_calls, random_state=random_state)

    def process_simulations(self, responses_list, inputs_list, saved_states_list, n_calls=30, random_state=42, save_path=None):
        """
        Processes multiple simulations and stores results.
        """
        for idx, (responses, inputs, saved_states) in enumerate(zip(responses_list, inputs_list, saved_states_list)):
            # Run Bayesian Optimization
            result = self.bayesian_optimization(responses, inputs, saved_states, n_calls, random_state)

            # Fit the model with the best parameters
            best_params = result.x
            fit_results = self.fit_glmhmm(best_params, responses, inputs, saved_states)

            # Append results
            self.posterior_probabilities_list.append(fit_results["posterior_probs"])
            self.observed_states_list.append(saved_states)
            self.glm_weights_list.append((fit_results["weights_state_1"], fit_results["weights_state_2"]))

            self.results.append({
                "simulation_index": idx,
                "best_rmse_total": fit_results["rmse_total"],
                "best_rmse_per": fit_results["rmse_per"],
                "best_rmse_eng": fit_results["rmse_eng"],
                "log_likelihood": fit_results["log_likelihood"],
                "best_prior_means": fit_results["prior_means"],
                "best_prior_sigmas": fit_results["prior_sigmas"],
                "best_weights_state_1": fit_results["weights_state_1"],
                "best_weights_state_2": fit_results["weights_state_2"],
                "transitions_log_ps": fit_results["transitions_log_ps"]
            })

            # Save intermediate results
            if save_path:
                with open(save_path, 'wb') as f:
                    pickle.dump(self.results, f)

    def get_results_dataframe(self):
        """
        Returns the results as a DataFrame.
        """
        return pd.DataFrame(self.results)


        
        