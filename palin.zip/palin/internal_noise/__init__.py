# Palin.internal_noise subpackage
